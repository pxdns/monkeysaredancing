#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec2 texCoord0;
in vec4 vertexColor;

out vec4 fragColor;

void main() {
    vec4 color = texture(Sampler0, texCoord0) * ColorModulator;
    //0.9647058823529412
    if (round(vertexColor.rgb * 1000000) == vec3(964706)) {
        float alpha = round(color.a * 100.0);
        if (alpha > 60.0) {
            discard;
        }
        if (alpha == 25.0) {
            color.rgb = vec3(1.0, 1.0, 0.34);
        }
        if (alpha == 50.0) {
            color.rgb = vec3(0.0);
        }
    } else {
        if (color.rgb == vec3(1.0, 0.0, 0.0)) {
            discard;
        } else {
            color *= vertexColor;
        }
    }
    if (color.a < 0.1) {
        discard;
    } else {
        color.a = 1.0;
    }
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
