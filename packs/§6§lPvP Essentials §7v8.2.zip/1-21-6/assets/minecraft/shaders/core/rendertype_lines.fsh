#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;

out vec4 fragColor;

void main() {
    vec4 color = vertexColor * ColorModulator;
    if (round(color.rgb) == vec3(1.0, 0.0, 0.0) || round(color.rgb) == vec3(0.0, 0.0, 1.0) || round(color.rgb) == vec3(1.0, 1.0, 0.0)) {
        discard;
    } else if (round(color.rgb) == vec3(1.0, 1.0, 1.0)) {
        float value = (20.0 - sphericalVertexDistance) / 10.0;
        color.a = value;
    }
    if (color.a < 0.1) {
        discard;
    }
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
