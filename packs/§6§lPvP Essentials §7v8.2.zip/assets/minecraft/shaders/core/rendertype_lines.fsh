#version 150

#moj_import <minecraft:fog.glsl>

uniform vec4 ColorModulator;
uniform float FogStart;
uniform float FogEnd;
uniform vec4 FogColor;

in float vertexDistance;
in vec4 vertexColor;

out vec4 fragColor;

void main() {
    vec4 color = vertexColor * ColorModulator;
    if (round(color.rgb) == vec3(1.0, 0.0, 0.0) || round(color.rgb) == vec3(0.0, 0.0, 1.0) || round(color.rgb) == vec3(1.0, 1.0, 0.0)) {
        discard;
    } else if (round(color.rgb) == vec3(1.0, 1.0, 1.0)) {
        float value = (20.0 - vertexDistance) / 10.0;
        color.a = value;
    }
    if (color.a < 0.1) {
        discard;
    }
    fragColor = linear_fog(color, vertexDistance, FogStart, FogEnd, FogColor);
}
